# 28-0

A one-file Ryder Cup draft game.

## How to publish on GitHub Pages

1. Create a new GitHub repo called `28-0`.
2. Upload `index.html` to the repo root.
3. Go to Settings → Pages.
4. Choose Deploy from branch → main → root.
5. Save.

Your game will be live at:
`https://YOUR-USERNAME.github.io/28-0/`
