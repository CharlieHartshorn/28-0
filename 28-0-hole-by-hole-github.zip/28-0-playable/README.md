# 28-0

A one-file Ryder Cup draft game.

## How to publish on GitHub Pages

1. Create a new GitHub repository called `28-0`.
2. Upload `index.html` to the root of the repository.
3. Go to **Settings → Pages**.
4. Choose **Deploy from branch**.
5. Select **main** and **/(root)**.
6. Save.

The game includes:

- Europe / USA team choice
- Easy / Medium / Hard rerolls
- Three-player choice every draft pick
- 12-player roster
- Auto-built foursomes and fourballs
- Singles order
- Hole-by-hole match simulation
- Results like 5&4, 2&1, 1 Up, or halved
- Share card

Unofficial fan-made game.
